<?php
/**
* Plugin Name: Compare Products
* Plugin URI: https://www.yourwebsiteurl.com/
* Description: Search Your Products
* Version: 1.0
* Author: Raja Sulal
* Author URI: http://rajasulal.bkytradings.com/
**/
defined('ABSPATH') || die("You can't Acess");
add_action( 'init' , 'product_shortcode' );
function product_shortcode(){
	add_shortcode( 'add_product_short_code' , 'my_product_shortcode' );
}
function my_plugin_activation(){
	//
}
register_activation_hook( __FILE__, 'my_plugin_activation' );

function my_plugin_deactivation(){
	//
}
register_deactivation_hook( __FILE__, 'my_plugin_deactivation' );


function my_product_shortcode(){ 

	include plugin_dir_path( __FILE__ )."inc/front-end.php";
}

function prefix_enqueue() 
{       
    wp_enqueue_style('woo_bootstrap' , plugin_dir_url( __FILE__ ).'css/bootstrap.css');
}
add_action( 'wp_enqueue_scripts' , 'prefix_enqueue' );

function my_admin_menu(){
	add_menu_page( 'Plugin Shortcode Detail' , 'Plugin Shortcode Detail' , 'manage_options' , 'plugin-shortcode-detail' , 'plugin_shortcode_detail' , '' , 4 );
	// add_submenu_page( 'plugin-shortcode-detail' , 'Sub Page' , 'Sub Page' , 'manage_options' , 'sub-page-slug' , 'sub_page_funciton' );
}
function plugin_shortcode_detail(){
	 include 'inc/plugin-menu-page.php';
}
// function sub_page_funciton(){
// 	 include '';
// }
add_action( 'admin_menu' , 'my_admin_menu' );