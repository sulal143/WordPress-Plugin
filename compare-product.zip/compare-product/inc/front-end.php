
<h1><label>Compare Product</label></h1>
	<form role="search" class="form-group" name="frm" action="<?php echo plugin_dir_url( __FILE__ ).'searchresult.php' ?>" method="GET">
		<div class="form-group">
			<label for="exampleInputEmail1">Product Title</label>
				<input type="text" class="form-control" placeholder="Product One" name="product_one" value="<?php echo isset($_GET['product_one']) ? $_GET['product_one'] : ''; ?>" required>
		</div>
		<div class="form-group">
			<label for="exampleInputPassword1">Product Title</label>
				<input type="text" class="form-control" placeholder="Product Two"name="product_two" value="<?php echo isset($_GET['product_two']) ? $_GET['product_two'] : ''; ?>" required>
		</div>
		<button type="submit" class="btn btn-primary">Compare Products</button>
	</form>