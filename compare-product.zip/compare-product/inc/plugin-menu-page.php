<div class="card">
	<h2>Enter This Shortcode:</h2>
	<p>add_product_short_code</p>
</div>