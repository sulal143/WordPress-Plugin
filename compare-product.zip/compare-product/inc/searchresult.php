<?php 
$parse_uri = explode( 'wp-content', $_SERVER['SCRIPT_FILENAME'] );
require_once( $parse_uri[0] . 'wp-load.php' );
get_header();

	$product_one = sanitize_text_field($_GET['product_one']);
	if ($_GET['product_one'] && !empty($_GET['product_one'])) 
	{
		$product_one =sanitize_text_field($_GET['product_one']);	
	}

	$product_two = $_GET['product_two'];
	if ($_GET['product_two'] && !empty($_GET['product_two'])) 
	{
		$product_two = sanitize_text_field($_GET['product_two']);	
	}
?>



<!-- Service Custom Query -->
<div class="container mt-5">
	<div class="row">
		<?php
			global $post;
			$product_1 = new WP_Query();
			$args = array(
				'post_type'      =>'product',
				'posts_per_page' => -1,
			);
			// Input Value Check 
			if ( isset($_GET['product_one'])) 
			{
			 	if(!empty($_GET['product_one']) )
			 	{
			 		$args['s'] = ( $_GET['product_one'] );
			 	}	
			}



			$product_1 = new WP_Query($args);

						// Input Value Check 
			if ( isset($_GET['product_two'])) 
			{
			 	if(!empty($_GET['product_two']) )
			 	{
			 		$args['s'] = sanitize_text_field( $_GET['product_two'] );
			 	}	
			}
			$product_2 = new WP_Query($args);
			$product = wc_get_product( $post_id );
		?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
			<h4 class="btn-danger text-center p-2">SHOW RESULT OF <?php echo $product_one;  ?> <?php esc_html_e( 'and', $domain = 'default' ) ?> <?php echo $product_two;  ?></h4>
		</div>
	</div>
</div>
		<div class="container">
			<div class="row">
				<?php if ($product_1->have_posts()): $product_1->the_post(); ?>
				<div class="col-md-6">
					<img src="<?php echo get_the_post_thumbnail_url( ) ?>" height="200px" widht="200px">
					<h3><?php the_title(); ?></h3>
					<p><?php the_content(); ?></p>
					<h3><?php esc_html_e( 'Price:' ); ?><?php echo $product->get_price(); ?></h3>
					<h3>
						<?php esc_html_e( 'Sale Price:' ); ?><?php echo $product->get_sale_price();?>
					</h3>
				</div>
				<?php endif; wp_reset_postdata();?>


				<?php if ($product_2->have_posts()): $product_2->the_post(); ?>
				<div class="col-md-6">
					<img src="<?php echo get_the_post_thumbnail_url( ) ?>" height="200px" widht="200px">
					<h3><?php the_title(  ); ?></h3>
					<p><?php the_content(); ?></p>
					<h3>
						<?php esc_html_e( 'Price:' ); ?><?php echo $product->get_regular_price();?>
					</h3>
					
					<h3>
						<?php esc_html_e( 'Sale Price:' ); ?><?php echo $product->get_sale_price();?>
					</h3>
					
										
				</div>
				<?php endif; wp_reset_postdata();?>
		</div>

	</div>
</div>
<?php 
get_footer();
?>