=== Compare Products ===
Contributors: Raja Muhammad Sulal
Tags: woocommerce product compare, compare woocommerce products
Donate link: #
Requires at least: 5.4
Tested up to: 5.8.2
Requires PHP: 7.0
Stable tag: 1.0
License: GPLv2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Compare woo-commerce Products with the help of a title.

== Description ==
Compare woo-commerce Products with the help of a title.

== Installation ==
Activate Plugin and Add shortcode.

== Screenshots ==
1. Activate
2. Menu Page
3. Shortcode